package eventsinformation;

/**
 *
 * @author isral
 */
public class NoAccessException extends Exception {

    public NoAccessException(String description) {
        super(description);
    }
    
}
